/*****************************************************************************/
/* This is the program skeleton for homework 2 in CSE167 by Ravi Ramamoorthi */
/* Extends HW 1 to deal with shading, more transforms and multiple objects   */
/*****************************************************************************/

// This file is display.cpp.  It includes the skeleton for the display routine

// Basic includes to get this file to work.  
#include "display.h"



void display()
{


    // steps for ray tracer display
    // create the scene using readfile info
    // ray trace the scene


    // Set up the camera view
    float one = 1.0;
    /*
    modelview = Transform::lookAt(eye, center, up);

    // Transformations for objects, involving translation and scaling
    float one = 1.0;
    mat4 sc(one), tr(one), transf(one);
    sc = Transform::scale(sx, sy, 1.0);
    tr = Transform::translate(tx, ty, 0.0);

    transf = modelview*(tr);
    transf = transf*(sc);
  
    modelview = transf;
     
    for (vector::iterator it = eachTriangle.begin(); it != eachTriangle.end(), ++it) {
        triangle(it.v1, it.v2, it.v3);
    }

    for (int i = 0; i < numobjects; i++) {
        object* obj = &(objects[i]); // Grabs an object struct.

        
        modelview = transf * obj->transform;

    }*/

}

Ray RayThruPixel(int x, int y) {
    /*
    vec3 wV = glm::normalize(eye - center);
    vec3 uV = glm::normalize(glm::cross(up, wV));
    vec3 vV = glm::normalize(glm::cross(wV, uV));
    double iF = i + 0.5;
    double jF = j + 0.5;
    double fovyRad = fovy * pi / 180;
    double aspect = w / (float)h;
    float alpha = tan(fovyRad / 2) * aspect * ((jF - (double)w / 2) / (w / 2));
    float beta = tan(fovyRad / 2) * (((double)h / 2 - iF) / (h / 2));
    vec3 p1 = glm::normalize(alpha * uV + beta * vV - wV);
    */


    float cal_fovy = fovy * pi / 180.0f;
    float fovx = tan(cal_fovy / 2.0f) * float(w) / float(h);
    float alpha = fovx * ((float(y + 0.5f) - w / 2.0f) / (w / 2.0f));
    float beta = tan(cal_fovy / 2.0f) * ((h / 2.0f) - float(x + 0.5f)) / (h / 2.0f);


    vec3 a = eye - center;
    vec3 w_vector = a.normalize();
    vec3 cross = vec3::cross(up, w_vector);
    vec3 u = cross.normalize();
    vec3 v = vec3::cross(w_vector, u);

    //r.direction = u * alpha + v * beta - w;
    //r.direction.normalize();

    Ray r(eye, u * alpha + v * beta - w_vector);
    return r;
}


float IntersectSphere(Ray r, Sphere* sphere) {
    mat4 Transform = mat4(sphere->transform);
    mat4 I_Transform = mat4::inverse(Transform);

    // in homogeneous coordinate
    vec4 Orign_4 = I_Transform * vec4(r.origin.x, r.origin.y, r.origin.z, 1.0);
    vec4 Direction_4 = I_Transform * vec4(r.direction.x, r.direction.y, r.direction.z, 0.0);
    vec3 Orign = vec3(Orign_4.x/Orign_4.w, Orign_4.y/Orign_4.w, Orign_4.z/Orign_4.w);
    vec3 Direction = vec3(Direction_4.x, Direction_4.y, Direction_4.z);

    //the equation of P
    float A = vec3::dot(Direction, Direction);
    float B = 2 * vec3::dot(Direction, Orign - sphere->center);
    float C = vec3::dot(Orign - sphere->center, Orign - sphere->center) - (sphere->radius * sphere->radius);
    float d = B * B - 4 * A * C;

    if (d < 0.0f)
    {
        return -1.0f;
    }
    else if (d < 0.001)
    {
        float t = -B  / (2 * A);
        vec3 p = Orign + Direction * t;
        vec4 Actual_Point_4 = Transform * vec4(p.x, p.y, p.z, 1);
        vec3 Actual_Point = vec3(Actual_Point_4.x, Actual_Point_4.y, Actual_Point_4.z);
        return t;
    }
    else
    {
        float t1 = (-B + sqrt(d)) / (2 * A);
        float t2 = (-B - sqrt(d)) / (2 * A);
        vec3 p_1 = Orign + Direction * t1;
        vec4 Actual_Point_4_1 = Transform * vec4(p_1.x, p_1.y, p_1.z, 1);
        vec3 Actual_Point_1 = vec3(Actual_Point_4_1.x, Actual_Point_4_1.y, Actual_Point_4_1.z);
        vec3 p_2 = Orign + Direction * t2;
        vec4 Actual_Point_4_2 = Transform * vec4(p_2.x, p_2.y, p_2.z, 1);
        vec3 Actual_Point_2 = vec3(Actual_Point_4_2.x, Actual_Point_4_2.y, Actual_Point_4_2.z);
        return min(t1, t2);
    }
}


float IntersectTriangle(Ray r, Triangle* tri) {
    //vec3 n = vec3::cross((tri->v3 - tri->v1), (tri->v2 - tri->v1)).normalize();

    //float t = (vec3::dot((tri->v1 - eye), n) - vec3::dot(r.origin, n)) / vec3::dot(r.direction, n);
;
    //vec3 P = r.origin + r.direction * t;
    
    vec3 A = tri->transform * tri->v1;
    vec3 B = tri->transform * tri->v2;
    vec3 C = tri->transform * tri->v3;
        
    vec3 n = vec3::cross((C - A), (B - A)).normalize();
    float t = (vec3::dot(A,n) - vec3::dot(r.origin,n)) / vec3::dot(r.direction,n);
    vec3 p = r.origin + r.direction * t;

    /*
    vec3 c0 = vec3::cross(tri->v2 - tri->v1, P - tri->v1);
    vec3 c1 = vec3::cross(tri->v3 - tri->v2, P - tri->v2);
    vec3 c2 = vec3::cross(tri->v1 - tri->v3, P - tri->v3);
    */
    if (HitInTriangle(p,A,B,C)) {
        return t;
    }
    return -1.0f;
}

// Use Barycentric coordinate take find out whether point inside the Triangle
bool HitInTriangle(vec3 P, vec3 A, vec3 B, vec3 C) {

    vec3 PA = P - A;
    vec3 PB = P - B;
    vec3 PC = P - C;

    vec3 AB = B - A;
    vec3 BC = C - B;
    vec3 AC = C - A;

    float areaPAB = (vec3::cross(PA, PB)).length();
    float areaPBC = (vec3::cross(PB, PC)).length();
    float areaPAC = (vec3::cross(PA, PC)).length();

    float areaABC = (vec3::cross(AB, AC)).length(); 

    float alpha = areaPBC / areaABC;
    float beta = areaPAC / areaABC;
    float gamma = areaPAB / areaABC;

    return 1.00001f > alpha > -0.00001f && 1.00001f > beta > -0.00001f && 1.00001f > gamma > -0.00001f && (0.99999f < (alpha + beta + gamma)) && ((alpha + beta + gamma) < 1.00001f);
}

float FindIntersect(Ray r, vector<Sphere> sceneSphere, vector<Triangle> sceneTriangle, bool* isTri) {
    float min_T = INFINITY; 

    *isTri = false;

    for (int i = 0; i < sceneSphere.size(); ++i) {
        // if intersects and is less than min T
        float temp_T = IntersectSphere(r, &sceneSphere[i]);
        if (temp_T > 0 && min_T > temp_T) min_T = temp_T;
    }
    for (int i = 0; i < sceneTriangle.size(); ++i) {
        float temp_T = IntersectTriangle (r, &sceneTriangle[i]);
        if (temp_T > 0 && min_T > temp_T) { 
            min_T = temp_T;
            *isTri = true;
        }
    }

    return min_T;
    
}

/*
vec3 FindColor(Intersection h) { 
   
}
*/




vector<vec3> Raytrace(int pix)
{
    vector<vec3> image(pix);
   
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < w; j++) {
            Ray ray = RayThruPixel(i, j);
            bool isTri;
            float hit = FindIntersect(ray, eachSphere, eachTriangle, &isTri);
            if (hit > 0 && hit < INFINITY) {
                if (isTri)
                    image[i * w + j] = vec3(100, 21, 1);
                else
                    image[i * w + j] = vec3(2, 210, 210);
                //cout << "--";
            }
            else {
                image[i * w + j] = vec3(0, 0, 0);
            }
            
        }
    }

    return image;

} 